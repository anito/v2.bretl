v 5.2.5.
see the following lines
4192 display: "inline" => display: "none"
4218 display: "inline" => display: "none"
http://jsbeautifier.org/
https://skalman.github.io/UglifyJS-online/